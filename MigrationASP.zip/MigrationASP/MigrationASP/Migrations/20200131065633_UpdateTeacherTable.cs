﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MigrationASP.Migrations
{
    public partial class UpdateTeacherTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "PhysExamResult",
                table: "Teachers",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PhysExamResult",
                table: "Teachers");
        }
    }
}
